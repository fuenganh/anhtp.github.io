from django.apps import AppConfig
#apps

class RegisterConfig(AppConfig):
    name = 'register'